package com.shiwu.demo.service;

import com.shiwu.demo.dao.StudentMapper;
import com.shiwu.demo.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 */
@Service
public class StudentService {
    @Autowired
    private StudentMapper studentMapper;

    public int add(List<Student> list) {
        for (Student student : list) {
            studentMapper.insert(student);
        }
       int cc= 1/0;
        return 1;
    }

    public Student find(int id) {
        return studentMapper.selectByPrimaryKey(id);
    }

    public int update(Student student) {
        return studentMapper.updateByPrimaryKeySelective(student);
    }

    public int delete(int id) {
        return studentMapper.deleteByPrimaryKey(id);
    }
}