package com.oceam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 本类功能简述：
 * 〈〉
 *
 * @author caidingnu
 * @create 2019/3/7
 * @since 1.0.0
 */
@Controller
@CrossOrigin("*")
public class Upload2 {
    //图片上传

    /**
     * 个人信息上传
     *
     * @return {Result}
     */
    @RequestMapping(value = "/upload", method = {RequestMethod.POST})
    @ResponseBody
    public Object headImg(@RequestParam(value = "file", required = false) MultipartFile file) throws Exception {
        String originalName = file.getOriginalFilename();

        File file1=new File("E:\\test\\"+originalName);
        file.transferTo(file1);
        List<String> list=new ArrayList<String>(){{
            add("0");
            add(originalName);
        }};

        return list;
    }
}