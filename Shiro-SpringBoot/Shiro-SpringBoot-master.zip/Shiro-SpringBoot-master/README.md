# [一. shiro 整合 springBoot 实现基本的角色权限控制](https://github.com/HowieYuan/Shiro-SpringBoot/blob/master/shiro%20%E6%95%B4%E5%90%88%20springBoot%20%E5%AE%9E%E7%8E%B0%E5%9F%BA%E6%9C%AC%E7%9A%84%E8%A7%92%E8%89%B2%E6%9D%83%E9%99%90%E6%8E%A7%E5%88%B6.md)
https://github.com/HowieYuan/shiro/tree/master/shiroSimple
# [二. shiro + springBoot 整合 JWT](https://github.com/HowieYuan/Shiro-SpringBoot/blob/master/shiro%20%2B%20springBoot%20%E6%95%B4%E5%90%88%20JWT.md)
https://github.com/HowieYuan/shiro/tree/master/shiroJWT
