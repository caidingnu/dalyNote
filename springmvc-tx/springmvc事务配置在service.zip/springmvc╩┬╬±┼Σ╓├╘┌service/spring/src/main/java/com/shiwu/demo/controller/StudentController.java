package com.shiwu.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.shiwu.demo.model.Student;
import com.shiwu.demo.model.Subject;
import com.shiwu.demo.service.StudentService;
import com.shiwu.demo.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("student")
@ResponseBody
public class StudentController {
    @Autowired
    private StudentService studentService;

    @Autowired
    SubjectService subjectService;

    @RequestMapping("add")
    public int add() throws Exception {
        Student student1 = new Student();
        student1.setName("刘备");
        student1.setAge(0);
        student1.setScores("55");
        student1.setCreateTime(new Date());
        student1.setUpdateTime(new Date());
        Student student2 = new Student();
        student2.setName("刘备");
        student2.setScores("55");
        student2.setCreateTime(new Date());
        student2.setUpdateTime(new Date());
        Student student3 = new Student();
        student3.setName("刘备");
        student3.setScores("55");
        student3.setCreateTime(new Date());
        student3.setUpdateTime(new Date());
        Student student4 = new Student();
        student4.setName("刘备");
        student4.setAge(0);
        student4.setScores("55");
        student4.setCreateTime(new Date());
        student4.setUpdateTime(new Date());
        Student student5 = new Student();
        student5.setName("刘备");
        student5.setAge(0);
        student5.setScores("55");
        student5.setCreateTime(new Date());
        student5.setUpdateTime(new Date());
        List<Student> list = new ArrayList<Student>();
        list.add(student1);
        list.add(student2);
        list.add(student3);
        list.add(student4);
        list.add(student5);
        int a = studentService.add(list);


        return 1;
    }

    @RequestMapping("find")
    public Student find(int id) {
        return studentService.find(id);
    }

    @RequestMapping("update")
    public int update(Student student) {
        return studentService.update(student);
    }

    @RequestMapping("delete")
    public int delete(int id) {
        return studentService.delete(id);
    }
}