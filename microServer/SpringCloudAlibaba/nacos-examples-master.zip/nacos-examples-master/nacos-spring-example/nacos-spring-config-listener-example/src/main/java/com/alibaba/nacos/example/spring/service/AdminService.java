package com.alibaba.nacos.example.spring.service;

import com.alibaba.nacos.example.spring.model.Admin;

/**
 * @author hexu.hxy
 * @date 2019/1/6
 */
public interface AdminService {

    Admin getAdmin();
}
