package com.shiwu.demo.controller;

import com.shiwu.demo.model.Subject;
import com.shiwu.demo.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by CodeX4J.
 */
@Controller
@RequestMapping("subject")
@ResponseBody
public class SubjectController {
    @Autowired
    private SubjectService subjectService;
    
    @RequestMapping("add")
    public int add(Subject subject) {
        return subjectService.add(subject);
    }
    
    @RequestMapping("find")
    public Subject find(int id) {
        return subjectService.find(id);
    }
    
    @RequestMapping("update")
    public int update(Subject subject) {
        return subjectService.update(subject);
    }
    
    @RequestMapping("delete")
    public int delete(int id) {
        return subjectService.delete(id);
    }
}