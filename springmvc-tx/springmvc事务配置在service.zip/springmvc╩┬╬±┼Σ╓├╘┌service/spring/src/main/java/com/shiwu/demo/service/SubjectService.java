package com.shiwu.demo.service;

import com.shiwu.demo.dao.SubjectMapper;
import com.shiwu.demo.model.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by CodeX4J.
 */
@Service
public class SubjectService {
    @Autowired
    private SubjectMapper subjectMapper;

    public int add(Subject subject) {
        return subjectMapper.insert(subject);
    }

    public Subject find(int id) {
        return subjectMapper.selectByPrimaryKey(id);
    }

    public int update(Subject subject) {
        return subjectMapper.updateByPrimaryKeySelective(subject);
    }

    public int delete(int id) {
        return subjectMapper.deleteByPrimaryKey(id);
    }
}