package com.stu.aoppermission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AoppermissionApplicationTests {

    @Test
    void contextLoads() {
    }

}
