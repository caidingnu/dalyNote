package com.stu.aoppermission.service;

/**
 * desc：
 * author CDN
 * create 2020-02-27 16:37
 * version 1.0.0
 */
public interface UserService {

boolean isAdmin( String currentUser );

}
